# Moviebot
This is a NodeJs webhook for dialogflow. /getMovies is the Api which is called from the Dialogflow. /getName is the test Api. This webhook makes use of the Tmdb Api to get the list of top rated, popular movies and details about specific movies. 
